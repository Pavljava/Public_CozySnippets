package com.scrappers.notepadpp;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Icon;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.github.clans.fab.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import static android.os.Environment.getExternalStorageDirectory;
import static android.os.Environment.getExternalStorageState;
import static com.scrappers.notepadpp.MainActivity.fileName;
import static com.scrappers.notepadpp.MainActivity.finalOutText;
import static com.scrappers.notepadpp.MainActivity.recordName;
import static com.scrappers.notepadpp.MainActivity.refer;

public class EditPaneActivity extends AppCompatActivity {
    public static EditText ed;
    FloatingActionButton playPause;
    FloatingActionButton recordPause;
    public static int id;
    AlertDialog d;
    public static String NewFileName;
    public static String path;
    public  EditText ed1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_pane);

        AccessMicPermissions();

        if(refer==1){
            ed = findViewById(R.id.edText);
            ed.setText(finalOutText);
            DefineExistingRecording(recordName);

        }else{
            ed = findViewById(R.id.edText);

        }



    }

    @Override
    public void onBackPressed() {
//         AlertDialog.Builder builder =
//                new AlertDialog.Builder(this);
//        builder.setMessage("Want to save this file by the Time ?")
//                // An OK button that does nothing
//                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int id) {
//                        long millis=System.currentTimeMillis();
//                        Date date=new Date(millis);
//                        writeTextFiles(getApplicationContext().getFilesDir() + "/" + date, ed.getText().toString());
//                        finish();
//                        startActivity(new Intent(getApplicationContext(),MainActivity.class));
//
//                    }
//                })
//                .setNegativeButton("No", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        finish();
//                        startActivity(new Intent(getApplicationContext(),MainActivity.class));
//
//                    }
//                })
//                .setCancelable(false);
//        AlertDialog d2 = builder.create();
//
//        d2.show();

//
//        DialogBox();
//        refer=0;
        startActivity(new Intent(getApplicationContext(),MainActivity.class));
        finish();
    }

    public void savebtnAction(View view){
            DialogBox();
            refer=0;
    }
    //write Text Files to External Storage
    protected void writeTextFiles(String path,String data){
        try {


            BufferedWriter writer=new BufferedWriter(new FileWriter(path));
            writer.write(data);
            Toast.makeText(getApplicationContext(),"Save Successful",Toast.LENGTH_LONG).show();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void DialogBox(){
        AlertDialog.Builder builder =
                new AlertDialog.Builder(this);
        final LayoutInflater inflater = this.getLayoutInflater();
        final View layout = inflater.inflate(R.layout.dialogboxlayout, null);
        builder.setView(layout);
        // Dialog will have "Make a selection" as the title
        builder.setMessage("Please Write SaveName For this file>>>:")
                // An OK button that does nothing
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        ed1 = layout.findViewById(R.id.nameofsavefile);
                            NewFileName=ed1.getText().toString();
                            if(!NewFileName.isEmpty()){
                                 path=getApplicationContext().getFilesDir() + "/" + NewFileName;
                                writeTextFiles(path, ed.getText().toString());
                                String pathForRecordings=getExternalStorageDirectory()+"/SPRecordings/"+NewFileName
                                        +".mp3";
                                DefineNewRecord(pathForRecordings);


                            }else{
                                long millis=System.currentTimeMillis();
                                Date date=new Date(millis);
                                 path=getApplicationContext().getFilesDir() + "/" + date.toLocaleString();
                                writeTextFiles(path, ed.getText().toString());
                                String pathForRecordings=getExternalStorageDirectory()+"/SPRecordings/"+NewFileName
                                        +".mp3";
                                DefineNewRecord(pathForRecordings);



                            }

                      }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                })
                .setCancelable(true);
        d = builder.create();

        d.show();
    }


    public void AccessMicPermissions() {
        if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ){
            if ( checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                    PackageManager.PERMISSION_GRANTED ){


            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.RECORD_AUDIO},
                        11);


            }
        }
    }

    MediaRecorder record;
    MediaPlayer playRecord;

    boolean recordstate=false;
    public void DefineNewRecord(String recordnameLocal) {
        recordPause=findViewById(R.id.Recordbtn);

        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                1);

        //Make New directory
        File companyFile=new File(getExternalStorageDirectory()+"/"+"SPRecordings");
        companyFile.mkdir();

            record = new MediaRecorder();
            record.reset();
            record.setAudioSource(MediaRecorder.AudioSource.MIC);
            record.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            record.setOutputFile(recordnameLocal);
            record.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);


            try {
                record.prepare();

            } catch (Exception error) {
                error.printStackTrace();

            }
        record.start();
        Toast.makeText(getApplicationContext(),"Start Recording on",Toast.LENGTH_LONG).show();


        }


    public void stopRecording() {
        try {
            record.stop();
            record.release();
            record = null;
            String pathForRecordings=getExternalStorageDirectory()+"/SPRecordings/"+NewFileName
                    +".mp3";
            DefineExistingRecording(pathForRecordings);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    boolean stopSimulate=false;
    public void playRecordingOrPause(View v){
        playPause=findViewById(R.id.playPause);
       try{
            if(stopSimulate==false){
                playRecord.start();
                Snackbar.make(v,"Playing Record",Snackbar.LENGTH_LONG).show();
                stopSimulate=true;
                playPause.setLabelText("Pause");
            }else{
                playRecord.pause();
                Snackbar.make(v,"Pausing Record play",Snackbar.LENGTH_SHORT).show();
                stopSimulate=false;
                playPause.setLabelText("Play");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void DefineExistingRecording(String recordName) {
        playRecord = new MediaPlayer();
        try {

            playRecord.setDataSource(recordName);
            playRecord.prepare();

        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"No Recordings for this Note,Yet",Toast.LENGTH_LONG).show();
        }
    }










    //FAB buttons Action Listener

    public void RecordBtn(View v){
        try{


            DialogBox();
        }catch(Exception error){
            error.printStackTrace();
            Snackbar.make(v,"Error Recording Lecture Check MIC Permissions",Snackbar.LENGTH_LONG).show();

        }
    }

    public void playRecordPauseBtn(View v){
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                4 );
            playRecordingOrPause(v);

    }

    public void StopRecordBtn(View view){
        stopRecording();
    }





//    public void onBackPressed(){
//        AlertDialog.Builder builder =
//                new AlertDialog.Builder(this);
//        final LayoutInflater inflater = this.getLayoutInflater();
//        final View layout = inflater.inflate(R.layout.dialogboxlayout, null);
//        builder.setView(layout);
//        // Dialog will have "Make a selection" as the title
//        builder.setMessage("Please Write SaveName For this file>>>:")
//                // An OK button that does nothing
//                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int id) {
//                        EditText ed1 = layout.findViewById(R.id.nameofsavefile);
//                        NewFileName=ed1.getText().toString();
//                        writeTextFiles(getExternalStorageDirectory() +"/Android/obb/com.Scrappers.NotePadPP/"+NewFileName,ed.getText().toString());
//                        finish();
//
//                    }
//                })
//                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        finish();
//                    }
//                })
//                .setCancelable(false);
//        d = builder.create();
//
//        d.show();
//
//    }

}
