package com.scrappers.notepadpp;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import static android.os.Environment.getExternalStorageDirectory;
import static com.scrappers.notepadpp.CustomListAdapter.Subtxtview;

public class MainActivity extends AppCompatActivity {
ArrayList<String> mainTitle=new ArrayList<>();
ArrayList<String> subTitle=new ArrayList<>();
ListView lsview;
static int refer=0;
static int referpoint2=0;
static String fileName;
static String recordName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //accessing permissions

        ReadExternalStoargePermission();
        WriteExternalStoargePermission();

        RootPermissions();
        //check files in the file systems /Storage/emulated/0/Android/com.Expand/
        if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.N ){
            readTxtFiles(getApplicationContext().getFilesDir()+"/");
//            System.out.print(getApplicationContext().getDataDir()+"/");
        }

        defineAdapter(mainTitle,subTitle);

    }

//    public void onResume(){
//        super.onResume();
//        getWindow().getDecorView().findViewById(R.id.listFiles).invalidate();
//    }



    protected  void RootPermissions(){
        try {
            Process p=Runtime.getRuntime().exec("su");
            Toast.makeText(this,"Root Granted",Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this,"Root Rejected",Toast.LENGTH_SHORT).show();
        }
    }
    protected void ReadExternalStoargePermission(){
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                4 );
    }
    protected void WriteExternalStoargePermission(){
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                1 );
    }



    protected void defineAdapter(ArrayList<String> mainText, final ArrayList<String> subText){



        final CustomListAdapter lsAdapter=new CustomListAdapter(this,mainTitle,subTitle);
        lsview=findViewById(R.id.listFiles);
        lsview.setAdapter(lsAdapter);


        lsview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                startActivity(new Intent(getApplicationContext(),EditPaneActivity.class));
                finish();
                fileName=lsAdapter.getItem(position);

                try {
                    readTextFiles(getApplicationContext().getFilesDir()+"/" + fileName);
                    recordName=getExternalStorageDirectory()+"/SPRecordings/"+fileName
                            +".mp3";
                    refer=1;
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });

        final AlertDialog.Builder builder =
                new AlertDialog.Builder(this);

        lsview.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {

                builder.setMessage("Are you Sure you want to delete this item ?")
                        // An OK button that does nothing
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                File file=new File(getApplicationContext().getFilesDir()+"/"+lsAdapter.getItem(position));
                                file.delete();

                                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                                finish();


                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        })
                        .setCancelable(false);
                AlertDialog d2 = builder.create();

                d2.show();
                return true;


            }
        });

    }



    static String finalOutText;
    protected void readTextFiles(String path){
        try{
            BufferedReader reader=new BufferedReader(new FileReader(path));
            //to avoid showing null results w/ attempt to open the item
            if(reader.ready()==false){
                finalOutText="";
                reader.close();
            }else {

                String outputText = reader.readLine() + "\n";

                while (reader.ready()) {
                    outputText += reader.readLine() + "\n";
                }
                finalOutText = outputText;
                reader.close();
                Toast.makeText(getApplicationContext(), "Read Successful", Toast.LENGTH_LONG).show();
            }
        }catch (IOException e){
            e.printStackTrace();
        }
    }

    protected void makeTheExpansionDir(String path) {
        File directory = new File(Environment.getExternalStorageDirectory() + path);
        directory.mkdirs();
    }

    protected void readTxtFiles(String path){
        try {
//            makeTheExpansionDir(path);
            makeTheExpansionDir(path);
            //declaring a fie instance w/ a specific read/write  path
            File files[] = new File(path).listFiles();
            //using for each to list all files
            for (int num=0;num<=files.length-1;++num) {
                    mainTitle.add(files[num].getName());
                Date d=new Date(files[num].lastModified());

                subTitle.add(String.valueOf(d.toLocaleString()));

            }


        }catch (NullPointerException e){
            e.printStackTrace();
        }
    }






    public void addnewNote(View view){


        startActivity(new Intent(getApplicationContext(),EditPaneActivity.class));
        finish();
        refer=0;
    }



}
